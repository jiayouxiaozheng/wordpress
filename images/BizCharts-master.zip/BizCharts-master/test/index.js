// general component
require('./specs/component/Chart');
