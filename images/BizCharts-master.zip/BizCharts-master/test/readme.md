# 由于测试框架的兼容性，内部版本的测试用例正在火速移植中，敬请等待。
# [站点](https://alibaba.github.io/BizCharts/demo.html)上一百多个 demo 都已经顺利正常运行。