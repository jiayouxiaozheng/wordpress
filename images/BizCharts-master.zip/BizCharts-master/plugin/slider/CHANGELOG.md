# 2.0.3 (04.10, 2018)
fix issue-210

# 2.0.1 (12.28, 2017)
upgrade g2-plugin-slider version 2.0.1.

# 2.0.0 (12.18, 2017)
修复包名，之前是 bizcharts-plugin-slier, 改为 bizcharts-plugin-slider
包入口之前有误，改为 bizcharts-plugin-slider.min.js

# 1.0.0 (12.12, 2017)
1.0.0 版本发布。
