/**
 * Coord Component
 */
import Base from '../Base';

export default Base.generateBaseTypedComponent('Coord');
