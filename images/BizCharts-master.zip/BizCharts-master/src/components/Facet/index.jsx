import BaseComponent from '../Base';

export default BaseComponent.generateBaseTypedComponent('Facet');

