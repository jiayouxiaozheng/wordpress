/**
 * Axis Component
 */
import Base from '../Base';

export default Base.generateBaseTypedComponent('Axis');
