
# Source Data

*Documents are forwarded from G2*

## Data Formats
Chart data supports two data formats：
- JSON
- Instance of DataView

### JSON (Array)
Example:

```js
var data = [
  {"gender":"male","count":40},
  {"gender":"female","count":30}
];
```

### DataView
See the detail at [DataSet](./dataset.md).
