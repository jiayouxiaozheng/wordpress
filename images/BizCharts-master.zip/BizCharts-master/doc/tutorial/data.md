
# 数据

*文档转自G2*

## 数据格式
图表数据支持两种数据格式：
- JSON数组
- DataView 对象。

### JSON 数组
Example:

```js
var data = [
  {"gender":"男","count":40},
  {"gender":"女","count":30}
];
```

### DataView
详见 [DataSet 教程](./dataset.md)。