import React, { Component } from 'react';
import Empty from './empty';


export default class LineChart extends Component {
  render() {
    return (
      <div className='empty-charts'>
        <Empty />
      </div>
    );
  }
}