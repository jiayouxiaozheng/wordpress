import React, { Component } from 'react';
// import China from './china';
// import DrillDown from './drill-down';


export default class MapChart extends Component {
  render() {
    return (
      <div className='map-charts'>
        <div className='map-chart-china'>
          {/* <China />
          <DrillDown /> */}
        </div>
      </div>
    );
  }
}
